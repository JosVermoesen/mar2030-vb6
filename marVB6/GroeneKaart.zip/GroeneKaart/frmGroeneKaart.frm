VERSION 5.00
Object = "{86CF1D34-0C5F-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCT2.OCX"
Object = "{BDC217C8-ED16-11CD-956C-0000C04E4C0A}#1.1#0"; "TABCTL32.OCX"
Object = "{C932BA88-4374-101B-A56C-00AA003668DC}#1.1#0"; "msmask32.ocx"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "Comdlg32.ocx"
Object = "{0ECD9B60-23AA-11D0-B351-00A0C9055D8E}#6.0#0"; "mshflxgd.ocx"
Begin VB.Form frmGroeneKaart 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Groene Kaart Auto"
   ClientHeight    =   6210
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   10815
   Icon            =   "frmGroeneKaart.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6210
   ScaleWidth      =   10815
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdAfdrukken 
      Caption         =   "&Afdruk via Sjabloon (voorgedrukt document maatschappij)"
      Enabled         =   0   'False
      Height          =   855
      Left            =   120
      TabIndex        =   69
      Top             =   5280
      Width           =   1965
   End
   Begin VB.CommandButton cbSchoon 
      Caption         =   "Schoon"
      Height          =   300
      Left            =   4200
      TabIndex        =   68
      Top             =   5400
      Width           =   1125
   End
   Begin VB.CheckBox cbKleur 
      Caption         =   "Kleur"
      Height          =   255
      Left            =   2160
      TabIndex        =   15
      TabStop         =   0   'False
      Top             =   4440
      Value           =   1  'Checked
      Width           =   855
   End
   Begin VB.ComboBox cbKwaliteit 
      Height          =   315
      ItemData        =   "frmGroeneKaart.frx":0442
      Left            =   2160
      List            =   "frmGroeneKaart.frx":0456
      Style           =   2  'Dropdown List
      TabIndex        =   14
      TabStop         =   0   'False
      Top             =   4080
      Width           =   1335
   End
   Begin VB.CommandButton cmdAfdruk 
      Caption         =   "Grafische &Afdruk op blanco groen papier.."
      Height          =   930
      Left            =   120
      Picture         =   "frmGroeneKaart.frx":047D
      Style           =   1  'Graphical
      TabIndex        =   13
      Top             =   4080
      Width           =   1965
   End
   Begin VB.CommandButton cmdHistoriek 
      Caption         =   "&Historiek"
      Height          =   300
      Left            =   4200
      TabIndex        =   12
      TabStop         =   0   'False
      Top             =   4080
      Width           =   1125
   End
   Begin VB.CommandButton cmdSluiten 
      Cancel          =   -1  'True
      Caption         =   "Sluiten"
      Height          =   300
      Left            =   4200
      TabIndex        =   16
      TabStop         =   0   'False
      Top             =   5760
      Width           =   1125
   End
   Begin MSComDlg.CommonDialog Teken 
      Left            =   5760
      Top             =   5400
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin TabDlg.SSTab SSTab1 
      Height          =   3975
      Left            =   120
      TabIndex        =   1
      Top             =   0
      Width           =   5265
      _ExtentX        =   9287
      _ExtentY        =   7011
      _Version        =   393216
      Style           =   1
      Tabs            =   4
      Tab             =   3
      TabsPerRow      =   4
      TabHeight       =   520
      TabCaption(0)   =   "Manueel"
      TabPicture(0)   =   "frmGroeneKaart.frx":08BF
      Tab(0).ControlEnabled=   0   'False
      Tab(0).Control(0)=   "lblInfo(0)"
      Tab(0).Control(1)=   "lblInfo(1)"
      Tab(0).Control(2)=   "lblInfo(2)"
      Tab(0).Control(3)=   "lblInfo(3)"
      Tab(0).Control(4)=   "lblInfo(4)"
      Tab(0).Control(5)=   "lblInfo(5)"
      Tab(0).Control(6)=   "lblInfo(6)"
      Tab(0).Control(7)=   "lblInfo(7)"
      Tab(0).Control(8)=   "lblInfo(8)"
      Tab(0).Control(9)=   "lblInfo(9)"
      Tab(0).Control(10)=   "dtpTot"
      Tab(0).Control(11)=   "mebTekstinfo(5)"
      Tab(0).Control(12)=   "mebTekstinfo(4)"
      Tab(0).Control(13)=   "mebTekstinfo(3)"
      Tab(0).Control(14)=   "mebTekstinfo(2)"
      Tab(0).Control(15)=   "mebTekstinfo(1)"
      Tab(0).Control(16)=   "mebTekstinfo(0)"
      Tab(0).Control(17)=   "dtpVan"
      Tab(0).Control(18)=   "cmbMaatschappij"
      Tab(0).Control(19)=   "cmbSoort"
      Tab(0).ControlCount=   20
      TabCaption(1)   =   "scanBeheer"
      TabPicture(1)   =   "frmGroeneKaart.frx":08DB
      Tab(1).ControlEnabled=   0   'False
      Tab(1).Control(0)=   "cmdBodem"
      Tab(1).Control(0).Enabled=   0   'False
      Tab(1).Control(1)=   "cmdVolgende"
      Tab(1).Control(1).Enabled=   0   'False
      Tab(1).Control(2)=   "cmdVorige"
      Tab(1).Control(2).Enabled=   0   'False
      Tab(1).Control(3)=   "cmdTop"
      Tab(1).Control(3).Enabled=   0   'False
      Tab(1).Control(4)=   "tbGK(0)"
      Tab(1).Control(4).Enabled=   0   'False
      Tab(1).Control(5)=   "tbGK(1)"
      Tab(1).Control(5).Enabled=   0   'False
      Tab(1).Control(6)=   "tbGK(2)"
      Tab(1).Control(6).Enabled=   0   'False
      Tab(1).Control(7)=   "cmdBewaar"
      Tab(1).Control(7).Enabled=   0   'False
      Tab(1).Control(8)=   "cmdBestand"
      Tab(1).Control(8).Enabled=   0   'False
      Tab(1).Control(9)=   "cmdScanNieuweAfbeelding"
      Tab(1).Control(9).Enabled=   0   'False
      Tab(1).Control(10)=   "cmdScanOpties"
      Tab(1).Control(10).Enabled=   0   'False
      Tab(1).Control(11)=   "cmdScan"
      Tab(1).Control(11).Enabled=   0   'False
      Tab(1).Control(12)=   "cmdUpdate"
      Tab(1).Control(12).Enabled=   0   'False
      Tab(1).ControlCount=   13
      TabCaption(2)   =   "XY Instellingen"
      TabPicture(2)   =   "frmGroeneKaart.frx":08F7
      Tab(2).ControlEnabled=   0   'False
      Tab(2).Control(0)=   "lblInfo(13)"
      Tab(2).Control(1)=   "lblInfo(14)"
      Tab(2).Control(2)=   "lblInfo(15)"
      Tab(2).Control(3)=   "lblInfo(16)"
      Tab(2).Control(4)=   "lblInfo(17)"
      Tab(2).Control(5)=   "lblInfo(18)"
      Tab(2).Control(6)=   "lblInfo(19)"
      Tab(2).Control(7)=   "lblInfo(20)"
      Tab(2).Control(8)=   "lblInfo(21)"
      Tab(2).Control(9)=   "lblInfo(22)"
      Tab(2).Control(10)=   "lblInfo(12)"
      Tab(2).Control(11)=   "lblInfo(11)"
      Tab(2).Control(12)=   "lblInfo(10)"
      Tab(2).Control(13)=   "mebXYPositie(9)"
      Tab(2).Control(14)=   "mebXYPositie(5)"
      Tab(2).Control(15)=   "mebXYPositie(6)"
      Tab(2).Control(16)=   "mebXYPositie(4)"
      Tab(2).Control(17)=   "mebXYPositie(8)"
      Tab(2).Control(18)=   "mebXYPositie(7)"
      Tab(2).Control(19)=   "mebXYPositie(3)"
      Tab(2).Control(20)=   "mebXYPositie(2)"
      Tab(2).Control(21)=   "mebXYPositie(1)"
      Tab(2).Control(22)=   "mebXYPositie(0)"
      Tab(2).Control(23)=   "cmdBewaren"
      Tab(2).Control(23).Enabled=   0   'False
      Tab(2).Control(24)=   "cmdWijzigen"
      Tab(2).Control(24).Enabled=   0   'False
      Tab(2).Control(25)=   "cmbFormaatTot"
      Tab(2).Control(26)=   "cmbFormaatVan"
      Tab(2).Control(27)=   "cbXYwijzigen"
      Tab(2).ControlCount=   28
      TabCaption(3)   =   "Lease Connect Import"
      TabPicture(3)   =   "frmGroeneKaart.frx":0913
      Tab(3).ControlEnabled=   -1  'True
      Tab(3).Control(0)=   "mfgLijst"
      Tab(3).Control(0).Enabled=   0   'False
      Tab(3).Control(1)=   "cbLeaseConnect"
      Tab(3).Control(1).Enabled=   0   'False
      Tab(3).ControlCount=   2
      Begin VB.CommandButton cbXYwijzigen 
         Caption         =   "Wijzigen via Kladblok"
         Height          =   495
         Left            =   -72120
         TabIndex        =   70
         Top             =   1440
         Width           =   2175
      End
      Begin VB.CommandButton cbLeaseConnect 
         Caption         =   "Import"
         Height          =   375
         Left            =   4200
         TabIndex        =   0
         Top             =   480
         Width           =   855
      End
      Begin VB.ComboBox cmbFormaatVan 
         Enabled         =   0   'False
         Height          =   315
         ItemData        =   "frmGroeneKaart.frx":092F
         Left            =   -71760
         List            =   "frmGroeneKaart.frx":093F
         Style           =   2  'Dropdown List
         TabIndex        =   52
         Top             =   2940
         Width           =   1785
      End
      Begin VB.ComboBox cmbFormaatTot 
         Enabled         =   0   'False
         Height          =   315
         ItemData        =   "frmGroeneKaart.frx":0979
         Left            =   -71760
         List            =   "frmGroeneKaart.frx":0989
         Style           =   2  'Dropdown List
         TabIndex        =   54
         Top             =   3240
         Width           =   1785
      End
      Begin VB.CommandButton cmdWijzigen 
         Caption         =   "&Wijzigen"
         Height          =   405
         Left            =   -72180
         TabIndex        =   41
         TabStop         =   0   'False
         Top             =   900
         Width           =   2205
      End
      Begin VB.CommandButton cmdBewaren 
         Caption         =   "&Instellingen bewaren"
         Enabled         =   0   'False
         Height          =   405
         Left            =   -72180
         TabIndex        =   40
         TabStop         =   0   'False
         Top             =   420
         Width           =   2205
      End
      Begin VB.CommandButton cmdUpdate 
         Caption         =   "Update"
         Enabled         =   0   'False
         Height          =   315
         Left            =   -71760
         TabIndex        =   39
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmdScan 
         Caption         =   "Software Scan"
         Enabled         =   0   'False
         Height          =   375
         Left            =   -72600
         TabIndex        =   38
         Top             =   840
         Width           =   1335
      End
      Begin VB.CommandButton cmdScanOpties 
         Caption         =   "Scan Opties"
         Enabled         =   0   'False
         Height          =   375
         Left            =   -72600
         TabIndex        =   37
         Top             =   420
         Width           =   1335
      End
      Begin VB.CommandButton cmdScanNieuweAfbeelding 
         Caption         =   "Afbeelding Scannen"
         Enabled         =   0   'False
         Height          =   795
         Left            =   -71220
         TabIndex        =   36
         Top             =   420
         Width           =   1275
      End
      Begin VB.CommandButton cmdBestand 
         Caption         =   "Bestand"
         Enabled         =   0   'False
         Height          =   375
         Left            =   -74880
         TabIndex        =   35
         TabStop         =   0   'False
         Top             =   420
         Width           =   975
      End
      Begin VB.CommandButton cmdBewaar 
         Caption         =   "Bewaren"
         Enabled         =   0   'False
         Height          =   375
         Left            =   -73800
         TabIndex        =   34
         TabStop         =   0   'False
         Top             =   420
         Width           =   975
      End
      Begin VB.TextBox tbGK 
         Height          =   315
         Index           =   2
         Left            =   -74340
         TabIndex        =   33
         Tag             =   "tbDocRef"
         ToolTipText     =   "Referte document Verzekeraar"
         Top             =   2700
         Width           =   3675
      End
      Begin VB.TextBox tbGK 
         Height          =   315
         Index           =   1
         Left            =   -74340
         TabIndex        =   32
         Tag             =   "tbOmschrijving"
         ToolTipText     =   "Naam Verzekeraar"
         Top             =   2340
         Width           =   3675
      End
      Begin VB.TextBox tbGK 
         Height          =   315
         Index           =   0
         Left            =   -74340
         TabIndex        =   31
         Tag             =   "tbSleutel"
         ToolTipText     =   "Code Verzekeraar"
         Top             =   1980
         Width           =   1095
      End
      Begin VB.CommandButton cmdTop 
         Caption         =   "Top"
         Height          =   495
         Left            =   -70560
         TabIndex        =   30
         Top             =   1440
         Width           =   615
      End
      Begin VB.CommandButton cmdVorige 
         Caption         =   "<"
         Height          =   495
         Left            =   -70560
         TabIndex        =   29
         Top             =   1980
         Width           =   255
      End
      Begin VB.CommandButton cmdVolgende 
         Caption         =   ">"
         Height          =   495
         Left            =   -70200
         TabIndex        =   28
         Top             =   1980
         Width           =   255
      End
      Begin VB.CommandButton cmdBodem 
         Caption         =   "Bodem"
         Height          =   495
         Left            =   -70560
         TabIndex        =   27
         Top             =   2520
         Width           =   615
      End
      Begin VB.ComboBox cmbSoort 
         Height          =   315
         ItemData        =   "frmGroeneKaart.frx":09C3
         Left            =   -73680
         List            =   "frmGroeneKaart.frx":09D9
         Style           =   2  'Dropdown List
         TabIndex        =   9
         Top             =   2640
         Width           =   3705
      End
      Begin VB.ComboBox cmbMaatschappij 
         Height          =   315
         ItemData        =   "frmGroeneKaart.frx":0A4F
         Left            =   -73680
         List            =   "frmGroeneKaart.frx":0A59
         Sorted          =   -1  'True
         Style           =   2  'Dropdown List
         TabIndex        =   2
         Top             =   480
         Width           =   3705
      End
      Begin MSComCtl2.DTPicker dtpVan 
         Height          =   285
         Left            =   -73680
         TabIndex        =   10
         Top             =   2970
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   503
         _Version        =   393216
         Format          =   165216256
         UpDown          =   -1  'True
         CurrentDate     =   37622
         MaxDate         =   38717
         MinDate         =   37622
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   0
         Left            =   -73680
         TabIndex        =   3
         Top             =   780
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   1
         Left            =   -73680
         TabIndex        =   4
         Top             =   1080
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   2
         Left            =   -73680
         TabIndex        =   5
         Top             =   1380
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   3
         Left            =   -73680
         TabIndex        =   6
         Top             =   1680
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   4
         Left            =   -73680
         TabIndex        =   7
         Top             =   1980
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebTekstinfo 
         Height          =   300
         Index           =   5
         Left            =   -73680
         TabIndex        =   8
         Top             =   2280
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   529
         _Version        =   393216
         PromptChar      =   "_"
      End
      Begin MSComCtl2.DTPicker dtpTot 
         Height          =   315
         Left            =   -73680
         TabIndex        =   11
         Top             =   3270
         Width           =   3705
         _ExtentX        =   6535
         _ExtentY        =   556
         _Version        =   393216
         Format          =   165216256
         UpDown          =   -1  'True
         CurrentDate     =   37667
         MaxDate         =   38717
         MinDate         =   37622
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   0
         Left            =   -73500
         TabIndex        =   42
         Top             =   720
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   1
         Left            =   -73500
         TabIndex        =   43
         Top             =   1020
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   2
         Left            =   -73500
         TabIndex        =   44
         Top             =   1320
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   3
         Left            =   -73500
         TabIndex        =   45
         Top             =   1620
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   7
         Left            =   -73500
         TabIndex        =   49
         Top             =   2910
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   8
         Left            =   -73500
         TabIndex        =   50
         Top             =   3240
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   4
         Left            =   -73500
         TabIndex        =   46
         Top             =   1920
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   6
         Left            =   -73500
         TabIndex        =   48
         Top             =   2580
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   5
         Left            =   -73500
         TabIndex        =   47
         Top             =   2220
         Width           =   1005
         _ExtentX        =   1773
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSMask.MaskEdBox mebXYPositie 
         Height          =   285
         Index           =   9
         Left            =   -70920
         TabIndex        =   51
         Top             =   2340
         Width           =   945
         _ExtentX        =   1667
         _ExtentY        =   503
         _Version        =   393216
         ClipMode        =   1
         BackColor       =   16777215
         ForeColor       =   0
         PromptInclude   =   0   'False
         AutoTab         =   -1  'True
         MaxLength       =   7
         Mask            =   "###/###"
         PromptChar      =   "_"
      End
      Begin MSHierarchicalFlexGridLib.MSHFlexGrid mfgLijst 
         Height          =   2895
         Left            =   120
         TabIndex        =   67
         Top             =   960
         Width           =   4935
         _ExtentX        =   8705
         _ExtentY        =   5106
         _Version        =   393216
         BackColor       =   -2147483624
         ForeColor       =   0
         FixedCols       =   0
         FocusRect       =   2
         AllowUserResizing=   1
         _NumberOfBands  =   1
         _Band(0).Cols   =   2
         _Band(0).GridLinesBand=   2
         _Band(0).TextStyleBand=   0
         _Band(0).TextStyleHeader=   0
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "XYverlies"
         Height          =   285
         Index           =   10
         Left            =   -71760
         TabIndex        =   66
         Top             =   2340
         Width           =   825
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Datummaskers Van/Tot"
         Height          =   285
         Index           =   11
         Left            =   -71760
         TabIndex        =   65
         Top             =   2640
         Width           =   1785
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "xy-Pos (mm.)"
         Height          =   285
         Index           =   12
         Left            =   -73500
         TabIndex        =   64
         Top             =   420
         Width           =   1005
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Naam Klant"
         Height          =   285
         Index           =   22
         Left            =   -74880
         TabIndex        =   63
         Top             =   720
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Straat/Nummer"
         Height          =   285
         Index           =   21
         Left            =   -74880
         TabIndex        =   62
         Top             =   1020
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Woonplaats"
         Height          =   285
         Index           =   20
         Left            =   -74880
         TabIndex        =   61
         Top             =   1320
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Polisnummer"
         Height          =   285
         Index           =   19
         Left            =   -74880
         TabIndex        =   60
         Top             =   1620
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Maatschappij"
         Height          =   285
         Index           =   18
         Left            =   -74880
         TabIndex        =   59
         Top             =   420
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Geldig VAN"
         Height          =   285
         Index           =   17
         Left            =   -74880
         TabIndex        =   58
         Top             =   2910
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Geldig TOT"
         Height          =   315
         Index           =   16
         Left            =   -74880
         TabIndex        =   57
         Top             =   3210
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Kenteken"
         Height          =   285
         Index           =   15
         Left            =   -74880
         TabIndex        =   56
         Top             =   1920
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Soort"
         Height          =   315
         Index           =   14
         Left            =   -74880
         TabIndex        =   55
         Top             =   2580
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Merk"
         Height          =   285
         Index           =   13
         Left            =   -74880
         TabIndex        =   53
         Top             =   2220
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Merk"
         Height          =   285
         Index           =   9
         Left            =   -74940
         TabIndex        =   26
         Top             =   2280
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Soort"
         Height          =   315
         Index           =   8
         Left            =   -74940
         TabIndex        =   25
         Top             =   2640
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Kenteken"
         Height          =   285
         Index           =   7
         Left            =   -74940
         TabIndex        =   24
         Top             =   1980
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Geldig TOT"
         Height          =   315
         Index           =   6
         Left            =   -74940
         TabIndex        =   23
         Top             =   3270
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Geldig VAN"
         Height          =   285
         Index           =   5
         Left            =   -74940
         TabIndex        =   22
         Top             =   2970
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Maatschappij"
         Height          =   285
         Index           =   4
         Left            =   -74940
         TabIndex        =   21
         Top             =   480
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Polisnummer"
         Height          =   285
         Index           =   3
         Left            =   -74940
         TabIndex        =   20
         Top             =   1680
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Woonplaats"
         Height          =   285
         Index           =   2
         Left            =   -74940
         TabIndex        =   19
         Top             =   1380
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Straat/Nummer"
         Height          =   285
         Index           =   1
         Left            =   -74940
         TabIndex        =   18
         Top             =   1080
         Width           =   1245
      End
      Begin VB.Label lblInfo 
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Naam Klant"
         Height          =   285
         Index           =   0
         Left            =   -74940
         TabIndex        =   17
         Top             =   780
         Width           =   1245
      End
   End
   Begin VB.Image imgFiguur 
      BorderStyle     =   1  'Fixed Single
      Height          =   6015
      Left            =   5520
      Stretch         =   -1  'True
      Top             =   120
      Width           =   5175
   End
End
Attribute VB_Name = "frmGroeneKaart"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim cnn As ADODB.Connection
Dim rs  As ADODB.Recordset

Dim BedrijfsLokatie As String
Dim BestandsNaamFiguur As String
Dim adoJetProvider As String

Dim GKIsKLAAR As Boolean


Private Sub cbSchoon_Click()

    Dim TelTot As Integer
    
    Me.mfgLijst.Clear
    Me.mfgLijst.Cols = 2
    Me.mfgLijst.Rows = 2
    Me.mfgLijst.ColWidth(0) = 2145
    Me.mfgLijst.ColAlignment(0) = 0
    Me.mfgLijst.ColAlignment(1) = 0
    Me.mfgLijst.ColWidth(1) = 2475
    Me.cmbMaatschappij.ListIndex = 0
    For TelTot = 0 To 5
        Me.mebTekstinfo(TelTot).Text = ""
    Next

End Sub

Private Sub cbXYwijzigen_Click()

    Shell "notepad.exe " + App.Path + "\gkauto.600", vbNormalFocus

End Sub

Private Sub cmbMaatschappij_Change()

    cmdWijzigen.Enabled = True

End Sub


Private Sub cmbMaatschappij_Click()
    
    Dim TelTot As Integer

    For TelTot = 0 To mebXYPositie.UBound
        mebXYPositie(TelTot).Text = "000/000"
        mebXYPositie(TelTot).Enabled = False
    Next
    cmbFormaatVan.Enabled = False
    cmbFormaatTot.Enabled = False

    cmdWijzigen.Enabled = False
    If cmbMaatschappij.ListIndex = 0 Then
        Me.cmdAfdrukken.Enabled = False
        Me.cmdAfdruk.Enabled = False
        cmdBewaren.Enabled = False
    Else
        'inladen van gegevens proberen
        'indien mogelijk dan afdruk mogelijk maken
        If LaadMijInfo(cmbMaatschappij.Text) Then
            Me.cmdAfdrukken.Enabled = True
            Me.cmdAfdruk.Enabled = True
        Else
            Me.cmdAfdrukken.Enabled = False
            Me.cmdAfdruk.Enabled = False
        End If
        cmdWijzigen.Enabled = True
    End If

    Dim slHier As String
    Dim SQLstring As String
    
        slHier = Left(cmbMaatschappij.Text, 4)
        If UCase(slHier) = "EERS" Then imgFiguur.Picture = Nothing: Exit Sub
        If rs.State Then
            rs.Close
        End If
        SQLstring = "SELECT * FROM NL_GroeneKaart WHERE tbSleutel = '" & slHier & "'"
        fnOpenDatabase (SQLstring)
        If rs.RecordCount = 1 Then
            'ok
            GKOphalen
            GKIsKLAAR = True
        Else
            MsgBox slHier & "NL-Afbeelding voor '" & slHier & "' niet gevonden.  Enkel afdruk via voorgedrukt document betrokken verzekeraar mogelijk...", vbInformation
            Me.cmdAfdruk.Enabled = False
        End If
        rs.Close
        
End Sub


Private Sub cmbMaatschappij_KeyPress(KeyAscii As Integer)

    If Command = "" Then KeyAscii = 0

End Sub


Private Sub cmdAfdrukken_Click()
    
    Dim KtrlBox As Integer
    
    KtrlBox = MsgBox("Breng ��n exemplaar voorgedrukte groene kaart voor deze verzekeraar in uw printer en druk OK voor vervolg.", vbOKCancel + vbDefaultButton2 + vbExclamation)
    If KtrlBox = vbOK Then
        Screen.MousePointer = vbHourglass
        DrukTekstAf
        Printer.EndDoc
        Printer.ScaleMode = vbTwips
        Screen.MousePointer = vbNormal
    End If

End Sub


Private Sub cmdBewaren_Click()

    Me.MousePointer = vbHourglass
    BewaarMijInfo cmbMaatschappij.Text
    Me.MousePointer = vbNormal

End Sub


Private Sub cmdHistoriek_Click()

    Shell "notepad.exe " + App.Path + "\gkauto.log", vbNormalFocus

End Sub


Private Sub cmdSluiten_Click()

    Unload Me
    
End Sub


Private Sub cmdUpdate_Click()

    Dim slHier As String
    Dim SQLstring As String
    Dim TelTot As Integer
        
    slHier = tbGK(0).Text
    If rs.State Then
        rs.Close
    End If
    SQLstring = "SELECT * FROM NL_GroeneKaart WHERE tbSleutel = '" & slHier & "'"
    fnOpenDatabase (SQLstring)
    If rs.RecordCount = 1 Then
        'ok
        For TelTot = 1 To 2
            rs(tbGK(TelTot).Tag).Value = tbGK(TelTot).Text
        Next
        rs.Update
     Else
        MsgBox "Gegevens voor '" & slHier & "' niet gevonden", vbInformation
    End If
    rs.Close
   
End Sub

Private Sub cmdWijzigen_Click()

    Dim TelTot As Integer

    'If Command <> "/GROENE KAART" Then
        MsgBox "Is in deze versie uitgeschakeld.  Mail info@rv.be indien U op de hoogte wenst gehouden te worden rondom nieuwe versies.", vbInformation
        Exit Sub
    'End If

    For TelTot = 0 To mebXYPositie.UBound
        mebXYPositie(TelTot).Enabled = True
    Next
    cmbFormaatVan.Enabled = True
    cmbFormaatTot.Enabled = True

End Sub


Private Sub Form_Load()

    Dim FlHier As Integer
    Dim Zoekstring As String

    On Error GoTo FoutBestand

    Set cnn = New ADODB.Connection
    Set rs = New ADODB.Recordset
    
    Me.cbKwaliteit.ListIndex = 2
    Me.Caption = "Groene Kaart Auto versie " & App.Major & "." & App.Minor & "." & App.Revision
    BedrijfsLokatie = App.Path & "\"
    adoJetProvider = "Provider=Microsoft.Jet.OLEDB.4.0;"
    'fnOpenDatabase ("NL_GroeneKaart")
    
    dtpVan.Value = Now
    dtpTot.Value = Now + 30
    cmbSoort.ListIndex = 0
    If Dir(App.Path + "\gkauto.600") = "" Then
    Else
        cmbMaatschappij.Clear
        cmbMaatschappij.AddItem "Eerst maatschapij kiezen a.u.b. !"
        FlHier = FreeFile
        Open App.Path + "\gkauto.600" For Input As FlHier
        Do While Not EOF(FlHier)
            Line Input #FlHier, Zoekstring
            If Left(Zoekstring, 4) = "IDK:" Then
                cmbMaatschappij.AddItem Mid(Zoekstring, 5), cmbMaatschappij.ListCount
            End If
        Loop
        Close FlHier
    End If
    cbSchoon_Click
    
    Exit Sub
    
FoutBestand:
    MsgBox App.Path + "\gkauto.600" + vbCrLf + " is defekt.  Installeer opnieuw of kontakteer R&VSoft !", vbCritical
    cmbMaatschappij.Enabled = False

End Sub


Private Sub Form_Unload(Cancel As Integer)

    On Error Resume Next
    rs.Close
    cnn.Close
    Set rs = Nothing
    Set cnn = Nothing
        
End Sub


Private Sub mebXYPositie_LostFocus(Index As Integer)

    cmdBewaren.Enabled = True

End Sub

Function LaadMijInfo(Sleutel As String) As Integer

    Dim FlHier As Integer
    Dim TelTot As Integer
    Dim Zoekstring As String

    LaadMijInfo = False
    If Dir(App.Path + "\gkauto.600") = "" Then
        MsgBox App.Path + "\gkauto.600" + vbCrLf + vbCrLf + "is nog niet aanwezig."
        Exit Function
    Else
        FlHier = FreeFile
        Open App.Path + "\gkauto.600" For Input As FlHier
        Do While Not EOF(FlHier)
            Line Input #FlHier, Zoekstring
            If Zoekstring = "IDK:" + Sleutel Then
                For TelTot = 0 To mebXYPositie.UBound
                    Line Input #FlHier, Zoekstring
                    mebXYPositie(TelTot).Text = Zoekstring
                Next
                LaadMijInfo = True
                Exit Do
            End If
        Loop
        Line Input #FlHier, Zoekstring
            cmbFormaatVan.ListIndex = Val(Zoekstring)
        Line Input #FlHier, Zoekstring
            cmbFormaatTot.ListIndex = Val(Zoekstring)
        Close FlHier
    End If

End Function


Sub BewaarMijInfo(Sleutel As String)

    Dim FlHier As Integer
    Dim TelTot As Integer
    Dim FlBackup As Integer
    Dim Zoekstring As String

    FlHier = FreeFile
    If Dir(App.Path + "\gkauto.600") = "" Then
    Else
        'Eerst vorige definitie zoeken en verwijderen
        Open App.Path + "\gkauto.600" For Input As FlHier
        FlBackup = FreeFile
        Open App.Path + "\gkauto.$$$" For Output As FlBackup
        Do While Not EOF(FlHier)
            Line Input #FlHier, Zoekstring
            If Zoekstring = "IDK:" + Sleutel Then
                For TelTot = 0 To mebXYPositie.UBound
                    Line Input #FlHier, Zoekstring
                Next
                Line Input #FlHier, Zoekstring 'formaatvan
                Line Input #FlHier, Zoekstring 'formaattot
            Else
                Print #FlBackup, Zoekstring + vbCrLf;
                For TelTot = 0 To mebXYPositie.UBound
                    Line Input #FlHier, Zoekstring
                    Print #FlBackup, Zoekstring + vbCrLf;
                Next
                Line Input #FlHier, Zoekstring  'formaatvan
                Print #FlBackup, Zoekstring + vbCrLf;
                Line Input #FlHier, Zoekstring  'formaattot
                Print #FlBackup, Zoekstring + vbCrLf;
            End If
        Loop
        Close FlHier
        Close FlBackup
        Kill App.Path + "\gkauto.600"
        If Dir(App.Path + "\gkauto.$$$") = "" Then
        Else
            Name App.Path + "\gkauto.$$$" As App.Path + "\gkauto.600"
        End If
    End If

    Open App.Path + "\gkauto.600" For Append As FlHier
    Print #FlHier, "IDK:" + Sleutel + vbCrLf;
    For TelTot = 0 To mebXYPositie.UBound
        Print #FlHier, mebXYPositie(TelTot).Text + vbCrLf;
    Next
    Print #FlHier, Format(cmbFormaatVan.ListIndex) + vbCrLf;
    Print #FlHier, Format(cmbFormaatTot.ListIndex) + vbCrLf;
    Close FlHier

End Sub


Private Sub cmdAfdruk_Click()

    Dim KtrlBox As Integer
    Dim TelTot As Integer
        
    If Me.cmbMaatschappij.ListIndex = 0 Then MsgBox "Verzekeraar aanduiden a.u.b.", vbExclamation: Exit Sub
    For TelTot = 0 To 5
        If TelTot = 2 Then
        Else
            If Me.mebTekstinfo(TelTot).Text = "" Then MsgBox "Eerst vervolledigen a.u.b.", vbInformation: Exit For
        End If
    Next
    KtrlBox = MsgBox("Sommige verzekeraars gaan mogelijk niet akkoord met deze werkwijze.  Gelieve dit zelf onder controle te houden." & vbCrLf & "Vervolg met afdrukken ?", vbDefaultButton2 + vbYesNo + vbQuestion)
    If KtrlBox = vbYes Then
        PrintAnywhere imgFiguur, Printer
    End If
  
End Sub


Private Sub cbLeaseConnect_Click()
   
    Dim strTB2() As String
    Dim strDATA() As String
    Dim FlHier As Integer
    Dim TelTot As Integer
    Dim strEenString As String
            
    On Error GoTo CancelError
    Me.Teken.filename = ""
    Me.Teken.CancelError = True
    Me.Teken.Filter = _
        "Lease Connect bestanden (IMAT*.csv)|IMAT*.csv"
        
    Me.Teken.ShowOpen
    FlHier = FreeFile
    Err = 0
    On Error Resume Next
    Open Me.Teken.filename For Input As FlHier
        Line Input #FlHier, strEenString
        strTB2 = Split(strEenString, ";")
        Line Input #FlHier, strEenString
        strDATA = Split(strEenString, ";")
    Close FlHier
    If Err Then MsgBox Error, vbExclamation, "Foutopvang bestandsysteem": Exit Sub
    If UBound(strTB2) <> 42 Then MsgBox "Andere versie Layout retourblok.  Installeer recente versie van GroeneKaart a.u.b.", vbExclamation: Exit Sub
    If UBound(strDATA) <> 42 Then MsgBox "Andere versie Layout retourblok.  Installeer recente versie van GroeneKaart a.u.b.", vbExclamation: Exit Sub
             
    cbSchoon_Click
    For TelTot = 0 To UBound(strTB2)
        Me.mfgLijst.AddItem strTB2(TelTot) & vbTab & strDATA(TelTot), mfgLijst.Rows - 1
    Next
    
    'Polisnummer
    If Mid(Me.mfgLijst.TextMatrix(2, 0), 1, 7) = "RFF+001" Then
        Me.mebTekstinfo(3).Text = Me.mfgLijst.TextMatrix(2, 1)
    End If
    
    'Naam Verzekeringsnemer
    If Mid(Me.mfgLijst.TextMatrix(5, 0), 1, 7) = "PTY+003" Then
        Me.mebTekstinfo(0).Text = Me.mfgLijst.TextMatrix(5, 1)
    End If

    'Straat en nr.
    If Mid(Me.mfgLijst.TextMatrix(7, 0), 1, 7) = "ADR+002" Then
        Me.mebTekstinfo(1).Text = Me.mfgLijst.TextMatrix(7, 1)
    End If

    'Plaat
    If Mid(Me.mfgLijst.TextMatrix(14, 0), 1, 7) = "RFF+010" Then
        Me.mebTekstinfo(4).Text = Me.mfgLijst.TextMatrix(14, 1)
    End If

    'Merk en type
    If Mid(Me.mfgLijst.TextMatrix(10, 0), 1, 7) = "ROD+001" Then
        Me.mebTekstinfo(5).Text = Me.mfgLijst.TextMatrix(10, 1)
    End If
    
    Dim Mij As String
    'Verzekeraar
    If Mid(Me.mfgLijst.TextMatrix(3, 0), 1, 7) = "PTY+006" Then
        Mij = Mid(Me.mfgLijst.TextMatrix(3, 1), 2)
    End If
    
    For TelTot = 0 To Me.cmbMaatschappij.ListCount
        If Mid(Me.cmbMaatschappij.List(TelTot), 1, 4) = Mij Then
            Me.cmbMaatschappij.ListIndex = TelTot
            Exit Sub
        End If
    Next
    MsgBox "Afbeelding groene kaart voor verzekeraar " & Mij & " niet beschikbaar.  Eerst volledige versie installeren a.u.b.", vbExclamation
    Exit Sub
    
CancelError:
    Screen.MousePointer = vbNormal

End Sub


Private Sub cmdBestand_Click()
   
    On Error GoTo CancelError
    Me.Teken.filename = ""
    Me.Teken.CancelError = True
    Me.Teken.Filter = _
        "Alle Figuurbestanden|*.bmp;*.dib;*.gif;*.jpg;*.wmf;*.emf;*.ico;*.cur;*.tif" & _
        "|JPEG bestanden (*.jpg)|*.jpg" & _
        "|GIF bestanden (*.gif)|*.gif" & _
        "|BITMAP bestanden (*.bmp;*.dib)|*.bmp;*.dib" & _
        "|META bestanden (*.wmf, *.emf)|*.wmf;*.emf" & _
        "|CURSOR bestanden (*.ico, *.cur)|*.ico;*.cur"
                
    Me.Teken.ShowOpen
    imgFiguur.Picture = LoadPicture(Me.Teken.filename)
    cmdBewaar.Enabled = True
    cmdBewaar.SetFocus
    BestandsNaamFiguur = Me.Teken.filename
    Exit Sub
    
CancelError:
    Screen.MousePointer = vbNormal

End Sub


Private Sub CmdBewaar_Click()

    Dim KtrlBox As Integer
    Dim TelTot As Integer

    If rs.State Then
    Else
        fnOpenDatabase ("NL_GroeneKaart")
    End If
    
BewaarAfbeelding:
    KtrlBox = MsgBox("Bewaren als nieuw", vbQuestion + vbYesNoCancel + vbDefaultButton3)
    If KtrlBox = vbCancel Then
        GoTo BewaarAfbeelding
    ElseIf KtrlBox = vbNo Then
        'Eerst zoeken...
        MsgBox "Nog niet beschikbaar in deze versie.  Bestaande records best manueel verwijderen uit de access database a.u.b.", vbInformation
        Exit Sub
    Else
        rs.AddNew
    End If
    For TelTot = 0 To 2
        rs(tbGK(TelTot).Tag).Value = tbGK(TelTot).Text
    Next
    DoEvents
    FileToBlob rs("tbobject"), BestandsNaamFiguur
    rs.Update
    cmdBestand.SetFocus
    cmdBewaar.Enabled = False

End Sub


Private Sub cmdBodem_Click()

    cmdBewaar.Enabled = False
    Schoon
    
    On Error GoTo ErrorMOVELAST
    If rs.State Then
    Else
        fnOpenDatabase ("NL_GroeneKaart")
    End If
    rs.MoveLast
    GKOphalen
    
ErrorMOVELAST:
        
End Sub


Private Sub cmdScan_Click()
   
    cmdBewaar.Enabled = False

    If rs.State Then
    Else
        fnOpenDatabase ("NL_GroeneKaart")
    End If
    
    Screen.MousePointer = vbHourglass
    'ImgScan1.ShowSetupBeforeScan = True
    'ImgScan1.ShowSelectScanner
        
    'If ImgScan1.StatusCode = 0 Then
        'scanner werd gekozen
    '    ImgScan1.OpenScanner
    '    If ImgScan1.StatusCode = 0 Then
    '        'scanner kan geopend worden
    '        'TIFF, JPG_File, BMP_Bitmap, AWD_MicrosoftFax
    '        '  1 ,       6 ,         3 ,                2
    '
    '        ImgScan1.FileType = JPG_File
    '        ImgScan1.Image = App.path & "\marscan.jpg"
    '        ImgScan1.PageOption = PromptToCreateNewFile
    '
    '        ImgScan1.StartScan
    '        If ImgScan1.StatusCode = 0 Then
    '            'scan met succes
    '            'opslaan en afbeelden
    '            imgFiguur.Picture = LoadPicture(ImgScan1.Image)
    '            'BewaarAfbeelding
    '            rs.AddNew
    '            rs("tbDatum") = Now
    '            rs("tbOmschrijving") = "Een testafbeelding " & Now
    '            DoEvents
    '            FileToBlob rs("tbobject"), ImgScan1.Image
    '            rs.Update
    '        End If
    '    End If
    '    ImgScan1.CloseScanner
    'End If
    Screen.MousePointer = vbNormal
    
End Sub


Private Sub cmdScanNieuweAfbeelding_Click()

    cmdBewaar.Enabled = False
    
    'ImgScan1.ShowScanNew
    
End Sub


Private Sub cmdScanOpties_Click()

    cmdBewaar.Enabled = False

    'ImgScan1.ShowScanPreferences
    
End Sub


Private Sub cmdTop_Click()

    Dim TelTot As Integer
    
    Schoon
    cmdBewaar.Enabled = False
    
    On Local Error GoTo ErrorMOVEFIRST
    If rs.State Then
    Else
        fnOpenDatabase ("NL_GroeneKaart")
    End If
    rs.MoveFirst
    BlobToFile rs("tbobject"), App.Path & "\marscan.jpg"
    For TelTot = 0 To 2
        tbGK(TelTot).Text = rs(tbGK(TelTot).Tag).Value
    Next
    On Error Resume Next
    imgFiguur.Picture = LoadPicture(App.Path & "\marscan.jpg")
    If Err Then MsgBox Error
    
ErrorMOVEFIRST:

End Sub


Private Sub cmdVolgende_Click()

    cmdBewaar.Enabled = False
    Schoon
    
    On Error GoTo ErrorMOVENEXT
    If rs.State Then
    Else
        cmdBodem_Click
        Exit Sub
    End If
    rs.MoveNext
    If rs.EOF Then
        cmdBodem_Click
        Exit Sub
    Else
        GKOphalen
    End If
    
ErrorMOVENEXT:

End Sub


Private Sub cmdVorige_Click()

    Schoon
    cmdBewaar.Enabled = False
        
    On Local Error GoTo ErrorBOF
    If rs.State Then
    Else
        cmdTop_Click
        Exit Sub
    End If
    rs.MovePrevious
    If rs.BOF Then
        cmdTop_Click
        Exit Sub
    Else
        GKOphalen
    End If
    
ErrorBOF:
    
End Sub


Function fnOpenDatabase(SQLBevel As String)

    If Dir(BedrijfsLokatie & "ASScan.mdb") = "" Then
    '    If Not CopyFile(App.Path, BedrijfsLokatie, "ASScan.mdb") Then
    '        MsgBox "ASScan.mdb is noodzakelijk.", vbExclamation
    '        Unload Me
    '        Exit Function
    '    End If
    End If
    
    On Error Resume Next
    cnn.Close

    cnn.Open adoJetProvider & _
        "Data Source=" & BedrijfsLokatie & _
        "ASScan.mdb;" & _
        "Persist Security Info=False"
    rs.CursorLocation = adUseClient
    rs.Open SQLBevel, cnn, adOpenDynamic, adLockOptimistic

End Function


' Copy a BLOB field's contents to a binary file.
Function BlobToFile(fld As ADODB.Field, filename As String, _
    Optional ChunkSize As Long = 8192)
    Dim fnum As Integer, bytesLeft As Long, bytes As Long
    Dim tmp() As Byte
    
    ' Raise an error if the field doesn't support GetChunk.
    If (fld.Attributes And adFldLong) = 0 Then
        Err.Raise 1001, , "Field doesn't support the GetChunk method."
    End If
    ' Open the file;, delete it firstoverwrite it if necessary.' Delete the
    ' file if it exists already, then create a new one.
    If Dir$(filename) <> "" Then Kill filename
    
    fnum = FreeFile
    Open filename For Binary As fnum
    ' Read the field's contents, and write it the data to the file.
    bytesLeft = fld.ActualSize
    
    Do While bytesLeft
        bytes = bytesLeft
        If bytes > ChunkSize Then bytes = ChunkSize
        tmp = fld.GetChunk(bytes)
        Put #fnum, , tmp
        bytesLeft = bytesLeft - bytes
    Loop
    Close #fnum
    
End Function


' Copy a file's contents into a BLOB field.
Function FileToBlob(fld As ADODB.Field, filename As String, _
    Optional ChunkSize As Long = 8192)
    
    Dim fnum As Integer, bytesLeft As Long, bytes As Long
    Dim tmp() As Byte
    
    ' Raise an error if the field doesn't support GetChunk.
    If (fld.Attributes And adFldLong) = 0 Then
        Err.Raise 1001, , "Field doesn't support the GetChunk method."
    End If
    ' Open the file; raise an error if the file doesn't exist.
    If Dir$(filename) = "" Then Err.Raise 53, , "File not found"
    
    fnum = FreeFile
    Open filename For Binary As fnum
    ' Read the file in chunks, and append data to the field.
    bytesLeft = LOF(fnum)
    Do While bytesLeft
        bytes = bytesLeft
        If bytes > ChunkSize Then bytes = ChunkSize
        ReDim tmp(1 To bytes) As Byte
        Get #1, , tmp
        fld.AppendChunk tmp
        bytesLeft = bytesLeft - bytes
    Loop
    
    Close #fnum
    
End Function


Sub PrintAnywhere(Src As Object, Dest As Object)
    
    Err = 0
    On Error Resume Next
    Screen.MousePointer = vbHourglass
    If Dest Is Printer Then
        'Set Printer = Printers(dokumentPrinterNr)
        On Error Resume Next
        'Printer.PaperBin = LaadTekst(App.Title, "dokumentPRINTER")
        'If Printer.Orientation = vbPRORLandscape Then
        '    Printer.Orientation = vbPRORPortrait
        '    DoEvents
        'End If
        Select Case Me.cbKwaliteit.ListIndex
            Case 0
                Printer.PrintQuality = vbPRPQDraft
                Refresh
            Case 1
                Printer.PrintQuality = vbPRPQLow
                Refresh
            Case 2
                Printer.PrintQuality = vbPRPQMedium
                Refresh
            Case 3
                Printer.PrintQuality = vbPRPQHigh
                Refresh
        End Select
        If Me.cbKleur.Value = vbChecked Then
            Printer.ColorMode = vbPRCMColor
        Else
            Printer.ColorMode = vbPRCMMonochrome
        End If
        DoEvents
        Printer.PaintPicture Src.Picture, 0, 0, Printer.Width - 500, Printer.Height - 500
        DoEvents
        If Left(cmbMaatschappij.Text, 4) = tbGK(0).Text Then
            DrukTekstAf
        End If
        Printer.EndDoc
        Printer.ScaleMode = vbTwips
    Else
        Dest.PaintPicture Src.Picture, Dest.Width / 2, Dest.Height / 2
    End If
    If Err Then MsgBox Error, vbInformation
    Screen.MousePointer = vbNormal
   
End Sub


Sub ResizePictureBoxToImage(pic As PictureBox, twipWd _
  As Integer, twipHt As Integer)
 
    ' This code assumes that all units are in twips.  If
    ' not, you must convert it to twips before calling
    ' this routine.  This also assumes that the image
    ' was blt'ed to 0,0.
    Dim BorderHt As Integer, BorderWd As Integer
    BorderWd = pic.Width - pic.ScaleWidth
    BorderHt = pic.Height - pic.ScaleHeight
    pic.Move pic.Left, pic.Top, twipWd + BorderWd, _
    twipHt + BorderHt

End Sub


Sub Schoon()
    
    Dim TelTot As Integer
    
    For TelTot = 0 To 2
        tbGK(TelTot).Text = ""
    Next
    Me.Refresh
    
End Sub

Function GKOphalen()
    
  Dim TelTot As Integer
  
    Screen.MousePointer = vbHourglass
    BlobToFile rs("tbobject"), App.Path & "\marscan.jpg"
    For TelTot = 0 To 2
        tbGK(TelTot).Text = rs(tbGK(TelTot).Tag).Value
    Next
    On Error Resume Next
    imgFiguur.Picture = LoadPicture(App.Path & "\marscan.jpg")
      
    If Err Then MsgBox Error
    Screen.MousePointer = vbNormal
    GKIsKLAAR = False

End Function


Function DrukTekstAf()

    Dim xVerlies As Single
    Dim yVerlies As Single
    Dim TelTot As Integer
    Dim FlHier As Integer

    Me.MousePointer = vbHourglass
    FlHier = FreeFile
    Open App.Path + "\gkauto.log" For Append As FlHier

    xVerlies = Left(mebXYPositie(9), 3)   'Horizontaal
    yVerlies = Right(mebXYPositie(9), 3)  'Vertikaal
    Printer.ScaleMode = vbMillimeters
    Printer.FontName = "Arial"
    Printer.FontSize = 10
    
    Print #FlHier, vbCrLf; "Voorlopige groene kaart, " + cmbMaatschappij.Text + " op " + Format(Now) + vbCrLf;
    For TelTot = 0 To 5
        Printer.CurrentX = Left(mebXYPositie(TelTot), 3) - xVerlies 'Horizontaal
        Printer.CurrentY = Right(mebXYPositie(TelTot), 3) - yVerlies 'Vertikaal
        Printer.Print mebTekstinfo(TelTot);
        Print #FlHier, mebTekstinfo(TelTot); vbCrLf;
    Next
    
    Printer.CurrentX = Left(mebXYPositie(6).Text, 3) - xVerlies 'Horizontaal
    Printer.CurrentY = Right(mebXYPositie(6).Text, 3) - yVerlies 'Vertikaal
    Printer.Print Left(cmbSoort.Text, 1);
    Print #FlHier, cmbSoort; vbCrLf;
    
    Printer.CurrentX = Left(mebXYPositie(7).Text, 3) - xVerlies 'Horizontaal
    Printer.CurrentY = Right(mebXYPositie(7).Text, 3) - yVerlies 'Vertikaal
    Printer.Print Format(dtpVan, cmbFormaatVan);
    Print #FlHier, Format(dtpVan, cmbFormaatVan); vbCrLf;
    
    Printer.CurrentX = Left(mebXYPositie(8).Text, 3) - xVerlies 'Horizontaal
    Printer.CurrentY = Right(mebXYPositie(8).Text, 3) - yVerlies 'Vertikaal
    Printer.Print Format(dtpTot, cmbFormaatTot);
    Print #FlHier, Format(dtpTot, cmbFormaatTot); vbCrLf;
    Close FlHier
    Me.MousePointer = vbNormal
    
End Function

